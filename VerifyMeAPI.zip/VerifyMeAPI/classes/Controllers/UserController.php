<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 18/06/2017
* Time : 03:42 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
//use \Interop\Container\ContainerInterface;
use Model\UserModel;
use Util\ResponseMessage;
use Util\ResponseCode;
use Utils\Util;

class UserController extends BaseController{

    public function login(Request $request, Response $response, $args){


    try{
            $input_data = $request->getParsedBody();
            if($input_data['username']!= null && $input_data['password']!= null){
              
                 $db_values = UserModel::login($input_data);
                if($db_values!= null){
                    if($db_values[0]['password']== $input_data['password']){
                     $data = [];
                     $details = UserModel::getUserDetails($input_data['username']);
                     $role = $details->role;
                     //session data
                     $data['session_id']= Util::getInstance()->startSession('id', 'loggedin'.' : '.$input_data['username']. ' : '. $role);
                     $_Session['role'] = $role; 
                     setcookie("user", $input_data['username'], time() - 3600); // expires after one hour.
                     setcookie("role", $role, time() - 3600); // expires after one hour.
                     unset($db_values[0]['password']);
                     $newData = array_merge($db_values[0],$data);
                    return $response->withJson(['status'=>true, 'data'=>$newData]);
                    }else{
                         return $response->withJson(['status'=>false, 'error_Message'=>ResponseMessage::INVALID_USERNAME_OR_PASSWORD, 
                         'error_code'=>ResponseCode::INVALID_USERNAME_OR_PASSWORD]);
                    }
                }else{
                    $data['session_id'] = null;
                    return $response->withJson(['status'=>false,'Error_Message'=>ResponseMessage::INVALID_USERNAME_OR_PASSWORD
                    ,'Error_code'=>ResponseCode::INVALID_USERNAME_OR_PASSWORD]);
                }
            }
        }catch(Exception $e){
            return $response->withJson(['Database_error'=>$e->getMessage()]);
         }

     }
}