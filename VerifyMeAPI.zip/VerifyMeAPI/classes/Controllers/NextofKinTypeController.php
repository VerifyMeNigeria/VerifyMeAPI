<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 01:52 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\NextofKinTypeModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class NextofKinTypeController extends BaseController{

    public function getNextofKinLevel(Request $request, Response $response, $args){
        try{
            $data = NextofKinTypeModel::getNextofKinType();
            if($data){
                return $response->withJson(['status'=>true, 'data'=>$data]);
            }
            return $response->withJson(['status'=>false, 'data'=>null]);
        }
        catch(Exception $e){
            $response->withJson($e->getMessage());
        }
    }
}