<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 15/08/2017
* Time : 01:39 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
//use \Interop\Container\ContainerInterface;
use Model\StaffEmployementHistoryModel;
use Util\ResponseMessage;
use Util\ResponseCode;
use Model\EmployersModel;
use Model\EmployeesModel;
use Model\LgaModel;
use Model\StateModel;
use Model\CountriesModel;
use Model\EducationModel;
use Model\EyeColourModel;
use Model\HairColourModel;

class StaffEmployementHistoryController extends BaseController{
    public function getEmployersStaffsAndDetails(Request $request, Response $response, $args){
            $result = [];
            $output = [];
            $limit = 5;
            $empCode = $request->getAttribute('empcode');
            $status = $request->getParam('status');
            $page_number = ($request->getParam('page', 0) > 0) ? $request->getParam('page') : 1;
            if(!empty($empCode)){
    
            $db_values = StaffEmployementHistoryModel::where('empCode','=',$empCode)
            ->where('status', $status)
            ->orderBy('staffID', 'ASC')
            ->skip($limit * ($page_number - 1))
            ->take($limit)
            ->get();
            $employeeCount = StaffEmployementHistoryModel::where('empCode','=',$empCode)
            ->where('status', $status)
            ->orderBy('staffID', 'ASC')->get();
            $pages = intval(ceil(count($employeeCount) / $limit));
            
            $data = $db_values->toArray();
            $employer_details = EmployersModel::getEmployersByCode($empCode);
            $result = array();
            $result['employer'] = (object)$employer_details[0];
            //if(!empty($data)){
                //find employee by staffid
                //find employer by empcode
                foreach($data as &$values){
                    
                    $staff_details = EmployeesModel::findEmployeeByStaffId($values['staffID']);
                    $emp_history_details = $values;
                    //convert object to Array
                    if(!empty($staff_details) && !empty($employer_details)){
                        $staff_detailsArray = $staff_details->toArray();
                        $lga = LgaModel::getLgaById($staff_detailsArray[0]['LGA_ID']);
                        $state = StateModel::listAllStatesByStateId($staff_detailsArray[0]['origin_state']);
                        $country = CountriesModel::listAllCountryByCountryCode($staff_detailsArray[0]['nationality']);
                        $education = EducationModel::listAllEducationById($staff_detailsArray[0]['education']);
                        $eyecolour = EyeColourModel::getEyeColourById($staff_detailsArray[0]['eye_colour']);
                        $haircolour = HairColourModel::listAllHairColourById($staff_detailsArray[0]['hair_colour']);
                        
                        $lgaArray = $lga->toArray();
                        $stateArray = $state->toArray();
                        $countryArray = $country->toArray();
                        $educationArray = $education->toArray();
                        $eyeColourArray = $eyecolour->toArray();
                        $hairColourArray = $haircolour->toArray();
                        //employer_details won't be convert to Array because getEmployersByCode() 
                        //already returns an array of the employer details.
                        $combine_data = array_merge($staff_detailsArray[0],$emp_history_details);
                        $newdata = array_merge($combine_data, $lgaArray[0]);
                        $newdataAndState = array_merge($newdata,$stateArray[0]);
                        $newdataAndStateAndcountry = array_merge($newdataAndState, $countryArray[0]);
                        $newdataAndStateAndcountryAndeducationArray = array_merge($newdataAndStateAndcountry, $educationArray[0]);
                        $dataAndeyecolour = array_merge($newdataAndStateAndcountryAndeducationArray,$eyeColourArray[0]);
                        $dataAndeyecolourAndhairColourArray = array_merge($dataAndeyecolour, $hairColourArray[0]);
                        $result['employee'][] = $dataAndeyecolourAndhairColourArray;
                       
                    }
                 }
                 
                  
                  $result['pagination'] = ['total_pages'=>$pages, 'current_page'=>$page_number];
                //return $result;
            
            

                
                $result = ['status'=>true, 'data'=> $result];
               
            }else{
                $result = ['status'=>false, 'Message'=>ResponseMessage::EMPCODE_ERROR,'Code'=>ResponseCode::EMPCODE_ERROR];
                
            }
            return $response->withJson($result);
        
    }

    public function getEmployeeHistorythatBelongToEmployer(Request $request, Response $response, $args){
        $data = $request->getParsedBody();
        if(!empty($data)){
            $db_values = StaffEmployementHistoryModel::getEmployeeHistorythatBelongToEmployer($data);
            if(!empty($db_values)){
                $result = ['status'=>true, 'data'=> $db_values];
            }else{
            $result = ['status'=>false, 'data'=> NULL];
            }
        }else{
        $result = ['status'=>false, 'Message'=>ResponseMessage::EMPCODE_ERROR,'Code'=>ResponseCode::EMPCODE_ERROR];
        }
        return $response->withJson($result);
    }

    public function disengageEmployeeByEmployer(Request $request, Response $response, $comment){
        $data = $request->getParsedBody();
        $empCode = $request->getAttribute('empcode');
        $staffid = $request->getParam('staffid');
        //print_r(json_encode([$data,$empCode,$staffid]));exit;
       // $comment = $request->getParsedBody();
        if(!empty($data) && !empty($empCode) && !empty($staffid)){
            StaffEmployementHistoryModel::disEngageEmployee($staffid,$empCode,$data);
            $result = ['status'=>true, 'message'=>'Staff Successfully Disengaged','data'=> $staffid];
           return $response->withJson($result);
        }
        else{
            $result = ['status'=>false, 'data'=> NULL];
            return $response->withJson($result);
        }
        $result = ['status'=>false, 'message'=>ResponseMessage::EMPCODE_STAFFID_STATUS, 'code'=>ResponseCode::EMPCODE_STAFFID_STATUS];
        return $response->withJson($result);
    }

    
}
