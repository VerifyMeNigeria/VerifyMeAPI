<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 10:39 AM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
//use \Interop\Container\ContainerInterface;
use Model\OccupationModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class OccupationController extends BaseController{

    public function getAllOccupation(Request $request, Response $response, $args){
        try{
            $data = OccupationModel::getoccupation();
            if($data){
                return $response->withJson(['status'=>true, 'data'=>$data]);
            }
            return $response->withJson(['status'=>false, 'data'=>null]);
        }
        catch(Exception $e){
            $response->withJson($e->getMessage());
        }
    }
}