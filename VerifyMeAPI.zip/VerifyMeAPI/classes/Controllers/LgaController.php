<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 10:39 AM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
//use \Interop\Container\ContainerInterface;
use Model\LgaModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class LgaController extends BaseController{

    public function getAllLgaByStateid(Request $request, Response $response, $args){
        try{
            $state_id = $request->getAttribute('state_id');
            if($state_id !=null){
                $data = LgaModel::getLgaByStateid($state_id);
                 return $response->withJson(['status'=>true, 'data'=>$data]);
            }
            return $response->withJson(['status'=>false, 'data'=>null]);
        }
        catch(Exception $e){
            $response->withJson($e->getMessage());
        }
    }
}