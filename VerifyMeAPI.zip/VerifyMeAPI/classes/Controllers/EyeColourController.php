<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 01:29 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\EyeColourModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class EyeColourController extends BaseController{

    public function getEyeColour(Request $request, Response $response, $args){
        try{
            $data = EyeColourModel::getEyeColour();
            if($data){
                return $response->withJson(['status'=>true, 'data'=>$data]);
            }
            return $response->withJson(['status'=>false, 'data'=>null]);
        }
        catch(Exception $e){
            $response->withJson($e->getMessage());
        }
    }
}