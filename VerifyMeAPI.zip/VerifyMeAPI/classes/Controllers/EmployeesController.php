<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 04:09 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\EmployeesModel;
use Model\EmployersModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class EmployeesController extends BaseController{
   
   /**
    * function to handle selfRegistration of an employee.
    *
    * @param Request $request
    * @param Response $response
    * @param [type] $args
    * @return void
    */
    public static function selfRegistration(Request $request ,Response $response, $args){
            $data = $request->getParsedBody();
            $result = [];
            try{
            $status = EmployeesModel::selfRegistration($data);
            if($status == true){
                $result = ['status'=>true, 'message'=>'Congratulations You have successfully Registered'];
            }else{
                $result = ['status'=>false , 'message'=> 'Registration was not sucessfully, Please try again'];
            }
                    
                
        }catch(Exception $e){
            $result = ['status'=>'error', 'db_error'=>$e->getMessage()];
        }

        return $response->withJson($result);
    }

    public static function CheckIfBvnOrPhoneExist(Request $request ,Response $response, $args){
        $data = $request->getParsedBody();
        $result = array();
        if(($data['phone_number']!= null && !empty($data['phone_number'])) && ($data['bvn']!= null && !empty($data['bvn'])) && !empty($data['other_number'])){
            $db_values = EmployeesModel::checkPhoneAndBvnIfExist($data);
            if($db_values!= null){
                if($db_values[0]['phone_numbers'] == $data['phone_number'] && $db_values[0]['bvn'] == $data['bvn'] && $db_values[0]['other_number'] == $data['other_number']){
                    
                    $result = ['phone_status'=>true, 'bvn_status'=>true, 'other_number'=>true,'message'=>'Sorry you have Registered with this phone number(s) And Bvn Already'];
               
                }elseif($db_values[0]['phone_numbers'] == $data['phone_number'] && $db_values[0]['bvn'] != $data['bvn'] && $db_values[0]['other_number']!= $data['other_number']){
                    
                    $result = ['phone_status'=>true, 'bvn_status'=>false, 'other_number'=>false, 'message'=>'Sorry you have Registered with this phone number Already'];
                
                }elseif($db_values[0]['bvn'] == $data['bvn'] && $db_values[0]['phone_numbers']!= $data['phone_number'] && $db_values[0]['other_number']!=$data['other_number']){
                    
                     $result = ['bvn_status'=>true, 'phone_status'=>false, 'other_number'=>false, 'message'=>'Sorry you have Registered with this Bvn Already'];
               
                }elseif($db_values[0]['phone_numbers'] != $data['phone_number'] && $db_values[0]['bvn'] != $data['bvn'] && 	$db_values[0]['other_number'] != $data['other_number']){
                    
                    $result = ['phone_status'=>false, 'bvn_status'=>false, 'other_number'=>false];
				}
                elseif($db_values[0]['bvn'] == $data['bvn'] && $db_values[0]['phone_numbers'] == $data['phone_number'] && $db_values[0]['other_number'] != $data['other_number']){
                    $result = ['phone_status'=>true, 'bvn_status'=>true, 'other_number'=>false, 'message'=>'Sorry you have registered with this bvn already'];
                }
                elseif($db_values[0]['bvn'] == $data['bvn'] && $db_values[0]['other_number'] == $data['other_number'] && $db_values[0]['phone_numbers'] != $data['phone_number']){
                    $result = ['bvn_status'=>true, 'other_number'=>true, 'phone_status'=>false, 'message'=>'Sorry you have registered with thi bvn and other number Already'];
                }
                elseif($db_values[0]['bvn'] != $data['bvn'] && $db_values[0]['other_number'] == $data['other_number'] && $db_values[0]['phone_numbers'] == $data['phone_number']){
                    $result = ['bvn_status'=>false, 'other_number'=>true, 'phone_status'=>true,'message'=>'Sorry you have Registered with this phone numbers Already'];
                }
                elseif($db_values[0]['other_number'] == $data['other_number'] && $db_values[0]['bvn'] != $data['bvn'] && $db_values[0]['phone_numbers'] != $data['phone_number']){
                      $result = ['phone_status'=>false, 'bvn_status'=>false, 'other_number'=>true, 'message'=>'Sorry you have Registered with the other number already'];
                }
                elseif(empty($data['phone_number'])){
       
                 $result = ['Phone'=>ResponseMessage::PHONE_MESSAGE,'code'=>ResponseCode::PHONE_MESSAGE];

                }elseif($data['bvn'] <= 0 || empty($data['bvn'])){
                $result = ['bvn_status'=>ResponseMessage::BVN_MESSAGE,'code'=>Responsecode::BVN_MESSAGE];
                 }
                   }else{
                    $result = ['phone_status'=>false, 'bvn_status'=>false, 'other_number'=>false];
                 }
             }else{
             $result = ['Phone'=>ResponseMessage::PHONE_MESSAGE,'code'=>ResponseCode::PHONE_MESSAGE, 'bvn_status'=>ResponseMessage::BVN_MESSAGE,'code'=>Responsecode::BVN_MESSAGE];
            }
             return $response->withJson($result);
         }

         public function saveEmployeeid(Request $request, Response $response, $args){
                $result = array();
                $data = EmployeesModel::saveStaffIdAndReturnTheStaffId();
                 if(!empty($data)){
                    $result = ['status'=>true, 'staffid'=> $data];
                    return $response->withJson($result);
                 }
             }

        public function findEmployeeByStaffId(Request $request, Response $response, $args){
            $result = [];
            $staffid = $request->getAttribute('staffid');
            $data = EmployeesModel::findEmployeeByStaffId($staffid);
            if(!empty($data)){
                $result = ['status'=>true, 'staffid'=> $data];
                    return $response->withJson($result);
            }
                return $response->withJson(['status'=>false, 'data'=>null]);
        }
    }

    