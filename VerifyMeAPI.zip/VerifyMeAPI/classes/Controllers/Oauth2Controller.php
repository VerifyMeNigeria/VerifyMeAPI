<?php

/**
 * Created by VSC
 * Author : Valentine Troy
 * Time:  12:05 PM
 * */
 
 use GuzzleHttp\Client as Client;

 class Oauth2Controller extends BaseController{
     private $redisCache;
        private $redisAuthPrefix = "vmn:oauth";
    protected $oauth_client_id = null;

    public function init(){
        $this->redisCache = RedisCache::init();
        $this->setCacheClass();
    }
 }