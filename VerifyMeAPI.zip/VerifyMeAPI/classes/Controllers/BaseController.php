<?php
use \Interop\Container\ContainerInterface;
/**
* Created by visual studio code 
* User : Valentine Troy Abako
* Date : 18/06/17
* Time : 2:31 PM
*/

abstract class BaseController{
    protected $container;

    //Constructor recieves container instance

    public function __construct(ContainerInterface $container){
        $this->container = $container;
    }

    public function sendSuccessResponse($data = array()){
        return withJson($data);
    }

    public function sendErrorResponse($data = array()){
        return $data;
    }
    
}
