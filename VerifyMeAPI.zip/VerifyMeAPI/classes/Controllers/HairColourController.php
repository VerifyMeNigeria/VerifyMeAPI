<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 28/06/2017
* Time : 01:39 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\HairColourModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class HairColourController extends BaseController{

    public function getHairColour(Request $request, Response $response, $args){
        try{
            $data = HairColourModel::getHairColour();
            if($data){
                return $response->withJson(['status'=>true, 'data'=>$data]);
            }
            return $response->withJson(['status'=>false, 'data'=>null]);
        }
        catch(Exception $e){
            $response->withJson($e->getMessage());
        }
    }
}