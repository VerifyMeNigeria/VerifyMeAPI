<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 18/06/2017
* Time : 03:42 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
//use \Interop\Container\ContainerInterface;
use Model\EmployersModel;
use Util\ResponseMessage;
use Util\ResponseCode;

class EmployersController extends BaseController{
    public function getEmployersByEmpcode(Request $request, Response $response, $empcode){

        try{
            $empcode = $request->getAttribute('empcode');
            $result = array();
            if(empty($empcode) || $empcode == null){
                $result = array('status'=>false,'data'=>null);
            }
            if($empcode!=null || !empty($empcode)){
                $db_values =  EmployersModel::getEmployersByCode($empcode);
                ;
                if($db_values!= null){
                    if($db_values[0]['empCode'] == $empcode){

                    $result = ['status'=>true, 'data'=>$db_values];
                    }else{
                        $result = ['status'=>false, 'error_Message'=>ResponseMessage::EMPCODE_ERROR, 'error_code'=>ResponseCode::EMPCODE_ERROR];
                    }
                }else{
                    $result = ['status'=>false, 'error_Message'=>ResponseMessage::EMPCODE_ERROR, 'error_code'=>ResponseCode::EMPCODE_ERROR];
                }
            }

            return $response->withJson($result);
                    
           
        }catch(Exception $e){
            return $response->withJson(['status'=>false,'Error_Message'=>ResponseMessage::EMPCODE_ERROR
                    ,'Error_code'=>ResponseCode::EMPCODE_ERROR, 'Exception'=> $e->getMessage()]);
        }
    }

    public function saveEmployer(Request $request, Response $response, $args)
    {
            $data = $request->getParsedBody();
            $output = array();
            
            try{
            $result = EmployersModel::createEmployer($data);
            if(!empty($result)){
                 $output = ['status'=>true, 'Message'=>'New Employer created', 'empcode'=> $result];
            }else{
                $output = ['status'=>false, 'Message'=>'Please fill all required Bills'];
            }
           

            }catch(Exception $ex){
            return $response->withJson(['status'=>'Exception error', 'Error_Message'=>ResponseMessage::EMPLOYER_ERROR, 'Error_code'=>ResponseCode::EMPLOYER_ERROR, 'Exception'=>$e->getMessage()]);
            }
        
        return $response->withJson($output);
    }

    public function editInfo(Request $request, Response $response, $empcode){
        $empcode = $request->getAttribute('empcode');
        $data = $request->getParsedBody();
        $output = array();
        if(!empty($empcode)){
            $result = EmployersModel::editInfo($empcode, $data);
            if(!empty($result)){
                $output = ['status'=>true, 'data'=>$result,'Message'=> 'Account Updated!'];
                return $response->withJson($output);
            }
            $output = ['status'=>false, 'data'=>null];
        }
        $output = ['status'=>false, 'data'=>null];
        return $response->withJson($output);
    }

}
