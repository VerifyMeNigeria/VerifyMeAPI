<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 14/08/2017
* Time : 10:36 PM
**/
namespace Controllers;
use BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\AddressVerification;
use Util\ResponseMessage;
use Util\ResponseCode;

class AddressVerificationController extends BaseController{

    public function saveAddressverification(Request $request, Response $response, $args){
            $data = $request->getParsedBody();
            $output = [];
           
            try{
            if(!empty($data)){
                 $result = AddressVerification::saveAddressverification($data);
                 $output = ['status'=>true, 'message'=>'Address saved', 'staffid'=>$result];
            }else{
                $output = ['status'=>false, 'message'=>'please fill all required field'];
            }
            
           return $response->withJson($output);
        }
        catch(Exception $ex){
            $response->withJson($e->getMessage());
        }
    }

    public function updateAddressVerification(Request $request, Response $response, $args){
            $id = $request->getAttribute('id');
            $data = $request->getParsedBody();
            $output = [];
           
            try{
            if(!empty($data)){
                 $result = AddressVerification::updateAddressVerification($data, $id);
                 $output = ['status'=>true, 'message'=>'Address Verified', 'staffid'=>$result];
            }else{
                $output = ['status'=>false, 'message'=>'please fill all required field'];
            }
            
           return $response->withJson($output);
        }
        catch(Exception $ex){
            $response->withJson($e->getMessage());
        }
    }
}

