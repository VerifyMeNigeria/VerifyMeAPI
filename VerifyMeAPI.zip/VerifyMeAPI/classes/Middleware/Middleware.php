<?php

namespace Middleware;

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 15th/07/2017
* Time : 03:42 PM
**/
class Middleware
{
    protected $container;

    function __construct($container)
    {
        $this->container = $container;
    }
    

}

