<?php 
/**
 * Created by VSC
 * @author Valentine Troy Abako.
 * @date  15th August 2017.
 */

namespace Middleware; 
use Utils\Util;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Model\UserModel;
class AuthMiddleware
{
    
    public function __invoke($request , $response, $next) {
            print_r(['user'=>$_COOKIE['role']]);exit;
        if(Util::getInstance()->isLoggedIn())
        {
            $user = Util::getInstance()->session('user');
             // Check if we have credentials in the header
            $role = $_SESSION['role'];
            $session_variable = $request->headers->get('session_id');
            if($role == 'Admin'){
                $response = $next($request, $response);
                return $response;
            }else{
               
                return $response->withStatus(302)->withHeader('location', '/logout');
            }    
            
        }
         
        return $response->withJson(['status'=>false, 'Message'=>'Please Login']);
    }

}
