<?php 
/**
 * Created by VSC
 * @author Valentine Troy Abako.
 * @date  15th August 2017.
 */
 namespace Middleware;
class GuestMiddleware extends Middleware
{
    
   /** public function __invoke($request, $response, $next)
    {   
        //check if the user is not signed in..
        $message = [];
        if($this->container->auth->check()){
           
           //return $response->withRedirect($this->container->router->pathFor('home'));
           $message = ['status'=>true, 'Message'=>'Please Login to Continue'];
           return $response->withJson($message);
        }
        $response = $next($request, $response);
        return $response;
    }
    **/
}
