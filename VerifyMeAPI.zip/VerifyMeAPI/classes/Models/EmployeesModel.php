<?php

/**
 * Created : VSC
 * @author Valentine Abako. 
 * Date    29-06-2017.
 */

namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;
use Model\UserModel;
use Model\EmailModel;
use Model\StaffEmployementHistoryModel;
use Model\EmployersModel;
use Model\GuarantorModel;
use Model\NextofKinModel;
use Model\AddressVerification;
use Utils\Util;

class EmployeesModel extends Emodel{
    
    public function __construct(){

    }

protected $table = 'employees';
    public $primaryKey = 'staffID';
    protected $timestamp = false;
    protected $fillable = ['staffID','title', 'firstname', 'middlename', 'surname', 'middlename','maidenname','nickname','gender','current_address','latlong','phone_numbers','other_number',
    'email','occupation','DOB','origin_state','LGA_ID','nationality','passport_nationalID','skills','assoc','police_rec','lasraID',
    'bvn','height','eye_colour','hair_colour','education','picture','maritalstatus','spousename','no_of_children','signature','sponsor','dateregistered',
    'lastupdated','reg_by','int_sms','updated_at','created_at','bvn_firstname','bvn_lastname','bvn_phonenumber','bvn_dob'];
    protected $guarded = [];

public function model($className = __CLASS__){
    parent::model($className);
}    
public static function selfRegistration($data = []){
     $result = array();
//default employee password = VMNUSR
    
    //find by staffid to update the rest details.
   
    $empObject = self::findEmployeeByStaffId($data['staffID']);
    $employer_detail = EmployersModel::getEmployersByCode($data['empcode']);//returns an empcode for a employer, if empcode exist;
    if($employer_detail[0]!=null){
        $employer_email = $employer_detail[0]['empEmail']; // returns employer-email if empcode is correct.
        $employer_name = $employer_detail[0]['empName'];
        $email_data = [];
        $email_data['empEmail'] = $employer_email;
        $email_data['empName'] = $employer_name;
        if($data['reg_by'] == 'Self')
        {
            $data['status'] = 'pending';
			StaffEmployementHistoryModel::saveStaffEmployeMentHistory($data);
        	EmailModel::sendEmail($email_data);
        }else if($data['reg_by'] != 'Self'){
            $data['status'] = 'active';
			StaffEmployementHistoryModel::saveStaffEmployeMentHistory($data);
            EmailModel::sendEmailToEmployersUsingDevice($email_data);
            
        }
        
    }else{
        $employer_email = null;
    }
    
    $empObject[0]->title = $data['title'];
    $empObject[0]->firstname = $data['firstname']; 
    $empObject[0]->middlename =$data['middlename'];
    $empObject[0]->surname = $data['surname'];
    $empObject[0]->gender = $data['gender'];
    $empObject[0]->nickname = ($data['nickname']) ? $data['nickname'] : null;
    $empObject[0]->current_address = $data['current_address']; 
    $empObject[0]->latlong = $data['latlong'];
    $empObject[0]->phone_numbers = $data['phone_numbers'];
    $empObject[0]->email = $data['email']; 
    $empObject[0]->occupation = $data['occupation'];
    $empObject[0]->DOB = $data['dob'];
    $empObject[0]->maidenname = (!empty($data['maidenname'])) ? $data['maidenname'] : null;
    $empObject[0]->origin_state = $data['origin_state'];
    $empObject[0]->LGA_ID = $data['lga']; 
    $empObject[0]->skills = $data['skills'];
    $empObject[0]->assoc = $data['assoc'];
    $empObject[0]->nationality = $data['nationality'];
    $empObject[0]->passport_nationalID = ($data['passport_nationalid']) ? $data['passport_nationalid'] : null;
    $empObject[0]->skills = $data['skills']; 
    $empObject[0]->assoc = $data['assoc'];
    $empObject[0]->police_rec = $data['police_rec'];
    $empObject[0]->lasraID = $data['lasraID'];
    $empObject[0]->bvn = $data['bvn'];
    $empObject[0]->height = $data['height']; 
    $empObject[0]->eye_colour = $data['eye_colour']; 
    $empObject[0]->hair_colour = $data['hair_colour'];
    $empObject[0]->education = $data['education']; 
    $empObject[0]->sponsor = $data['sponsor'];
	$empObject[0]->bvn_firstname = ($data['bvn_firstname']) ? $data['bvn_firstname'] : null;
    $empObject[0]->bvn_lastname = ($data['bvn_lastname']) ? $data['bvn_lastname'] : null;
    $empObject[0]->bvn_phonenumber = ($data['bvn_phonenumber']) ? $data['bvn_phonenumber'] : null;
    $empObject[0]->bvn_dob = ($data['bvn_dob']) ? $data['bvn_dob'] : null ;
    if(empty($data['email'])){
        $empObject[0]->email = null;
    }else{
        $empObject[0]->email = $data['email'];
    }
    //handling image upload
    $storage = './pictures';
    $folder = '/';
    $image = Util::uploadFromData($data['picture'], $storage, $data['staffID'], $folder);   
    $empObject[0]->picture = $image;
    $empObject[0]->maritalstatus = $data['maritalstatus']; 
    $empObject[0]->spousename = ($data['spousename']) ? $data['spousename']: null;
    $empObject[0]->no_of_children = $data['no_of_children'];
    $empObject[0]->signature = null; 
    $empObject[0]->sponsor = $data['sponsor']; 
    $empObject[0]->dateregistered = $data['dateregistered'];
    //last-updated will go in as update. 
    $empObject[0]->reg_by = $data['reg_by'];
    $empObject[0]->save();
    //int_sms will be updated as soon as sms is sent.
    NextofKinModel::saveEmployeeNextOfKin($data);
    GuarantorModel::saveGuarantor($data);
    AddressVerification::saveAddressverification($data);
    UserModel::insertUser($data);
    return true;


    
}

public static function saveStaffIdAndReturnTheStaffId(){
    $empObject =  new EmployeesModel();
    $staffid = self::checkIfStaffIdExistAndCreateNewEmpcode();
    $empObject->staffID = $staffid;
    $empObject->save();
    return $staffid;

}

/**
 * Undocumented function
 *
 * @return void
 */
public static function checkIfStaffIdExistAndCreateNewEmpcode(){
        $array_result = array();
        do{
            $employee_id = self::generateEmployeeId();
            $db_value = EmployeesModel::where('staffID','=', $employee_id);
            if(empty($db_value->staffID)){
                return $employee_id;
            }

            }while($db_value->staffID != $employee_id);
        
            return $employee_id;
    }

/**
 * function generate nine random numbers as employeeId, using 
 * the social number format e.g 123-45-8999
 * @return string 
 */

public static function generateEmployeeId(){
    $gen_rand = implode('-',str_split(rand(10000,99999),3)); // returns xxx-xx
    $gend_rand1 = rand(1000,9999);

    return $gen_rand.'-'.$gend_rand1;  //returns xxx-xx-xxxx  
}

/**
 * function checks if the phone number or 
 * bvn of a user exist
 * @param array $data
 * @return boolean
 */
public static function checkPhoneAndBvnIfExist($data = array()){
    $result = EmployeesModel::where('phone_numbers','=',$data['phone_number'])
            ->orWhere('bvn','=',$data['bvn'])
			->orWhere('other_number','=',$data['other_number'])->get();
            $formatted_result = $result->toArray();
            if(empty($formatted_result)){
                return null;
            }
            return $formatted_result;
}
public static function findEmployeeByStaffId($data){
    $obj = EmployeesModel::where('staffID', '=', $data)->get();
    if(!empty($obj)){
        return $obj;
    }

}



}