<?php

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;
use Model\EmployersModel;
use Model\EmployeesModel;
use Model\LgaModel;
use Model\StateModel;
use Model\CountriesModel;
use Model\EducationModel;
use Model\EyeColourModel;
use Model\HairColourModel;

class StaffEmployementHistoryModel extends Emodel{
    protected $table = "staff_employment_history";
    protected $fillable = ['historyEntryID','staffID','empCode', 'comment','created_at','updated_at', 'startDate','endDate','status'];
    protected $guarded =[];
    public $timestamp = false;
    public $primaryKey = 'historyEntryID';

    public function __construct(){

    }

    public function model($className = __CLASS__){
        return $className;
    }

    public static function saveStaffEmployeMentHistory($data = []){
        $obj = new StaffEmployementHistoryModel($data);
        $obj->historyEntryID = $data['historyEntryID'];
        $obj->staffID = $data['staffID'];
        $obj->status = $data['status'];
        $obj->startDate = $data['startDate'] ? $data['startDate'] : null;
        if(!empty($data['empcode'])){
            $obj->empCode = $data['empcode'];
        }else{
            $obj->empCode = null ;
        }
        
        $obj->save();
    }

    public static function getEmployeeHistorythatBelongToEmployer($data = array()){
            $staff_details = EmployeesModel::findEmployeeByStaffId($data['staffID']);
             $staff_detailsArray = $staff_details->toArray();
             $db_values = StaffEmployementHistoryModel::where('empCode','=', $data['empCode'])->get();
             $newdata = $db_values->toArray();
             $result = [];
             $number = $data['current_page'];
             $limit = 25;
                $employeeworkHistory = StaffEmployementHistoryModel::where('staffID','=',$newdata[0]['staffID'])
                ->where('staffID', '=',$data['staffID'])
                ->orderBy('staffID', 'ASC')
                ->skip($limit * ($number - 1))
                ->take($limit)
                ->get();
                $employeeCount = StaffEmployementHistoryModel::where('staffID','=',$newdata[0]['staffID'])->get();
                $pages = intval(ceil(count($employeeCount) / $limit));
                

                if(!empty($staff_details)){
                        $staff_detailsArray = $staff_details->toArray();
                        $lga = LgaModel::getLgaById($staff_detailsArray[0]['LGA_ID']);
                        $state = StateModel::listAllStatesByStateId($staff_detailsArray[0]['origin_state']);
                        $country = CountriesModel::listAllCountryByCountryCode($staff_detailsArray[0]['nationality']);
                        $education = EducationModel::listAllEducationById($staff_detailsArray[0]['education']);
                        $eyecolour = EyeColourModel::getEyeColourById($staff_detailsArray[0]['eye_colour']);
                        $haircolour = HairColourModel::listAllHairColourById($staff_detailsArray[0]['hair_colour']);
                        
                        $lgaArray = $lga->toArray();
                        $stateArray = $state->toArray();
                        $countryArray = $country->toArray();
                        $educationArray = $education->toArray();
                        $eyeColourArray = $eyecolour->toArray();
                        $hairColourArray = $haircolour->toArray();
                        //employer_details won't be convert to Array because getEmployersByCode() 
                        //already returns an array of the employer details.
                        $combine_data = $staff_detailsArray[0];
                        $newdata = array_merge($combine_data, $lgaArray[0]);
                        $newdataAndState = array_merge($newdata,$stateArray[0]);
                        $newdataAndStateAndcountry = array_merge($newdataAndState, $countryArray[0]);
                        $newdataAndStateAndcountryAndeducationArray = array_merge($newdataAndStateAndcountry, $educationArray[0]);
                        $dataAndeyecolour = array_merge($newdataAndStateAndcountryAndeducationArray,$eyeColourArray[0]);
                        $dataAndeyecolourAndhairColourArray = array_merge($dataAndeyecolour, $hairColourArray[0]);
                        $result['employee'] = $dataAndeyecolourAndhairColourArray;
                        $employeeworkHistoryArray = $employeeworkHistory->toArray();
                            //650-00-9954
                        if(empty($employeeworkHistoryArray)){
                        return null;
                        }

                        $result['pagination'] = ['total_pages'=>$pages, 
                                                'current_page'=>$number,
                                                'lastpage'=> (ceil($pages / $limit) == 0 ? 1 : ceil($pages / $limit)),
                                                'per_page'=> $limit];
                        
                         foreach($employeeworkHistoryArray as &$values){
                             $employer_details = EmployersModel::getEmployersByCode($values['empCode']);
                             $emp_history_details = $values;
                             $combine_data = array_merge($employer_details[0], $emp_history_details);
                             $result['employee_work_history'][] =  $combine_data; 
                            
                         }
                        return $result;         
                    }

         }

        public static function disEngageEmployee($staffID, $empcode, $data){
                $db_values = StaffEmployementHistoryModel::where('staffID','=',$staffID)->where('empCode','=',$empcode)->where('status','=','active')->first();
                //print_r(json_encode($db_values));exit;
                if(!empty($db_values)){
                
                $db_values->status = 'disengage';
                $db_values->comment = $data['comment'];
                $db_values->save();
                return $db_values->staffID;
            }
            return $db_values->staffID;
        }
}
