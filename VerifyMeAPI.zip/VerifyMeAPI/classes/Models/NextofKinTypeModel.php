<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class NextofKinTypeModel extends Emodel{

 protected $table = 'noktypes';
  
    public $timestamp = false;
    public $fillable = ['nokTypeID','NOK'];
    public $guarded = [];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getNextofKinType(){
        $db_value = NextofKinTypeModel::orderBy('NOK')->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
