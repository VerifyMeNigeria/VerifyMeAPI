<?php

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;

class NextofKinModel extends Emodel{
    protected $table = "nok";
    protected $fillable = ['kinInfoID','nokName','nokRelationship','nokPhone','nokEmail','staffID','created_at','updated_at'];
    protected $guarded =[];

    public function __construct(){

    }

    public function model($className = __CLASS__){
        return $className;
    }

    public static function saveEmployeeNextOfKin($data = array()){
        $obj =  new NextofKinModel($data);
        $obj->kinInfoID = $data['kinInfoID'];
        $obj->nokName = $data['nokName'];
        $obj->nokRelationship = $data['nokRelationship'];
        $obj->nokPhone = $data['nokPhone'];
        $obj->nokEmail = ($data['nokEmail']) ? $data['nokEmail'] : null;
        $obj->staffID = $data['staffID'];
        if(!empty($obj)){
            $obj->save();
        }

    }


}
