<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class OccupationModel extends Emodel{

 protected $table = 'occupations';
  
    public $timestamp = false;
    public $fillable = ['occupationID','Occupation'];
    public $guarded = [];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getoccupation(){
        $db_value = OccupationModel::orderBy('Occupation')->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
