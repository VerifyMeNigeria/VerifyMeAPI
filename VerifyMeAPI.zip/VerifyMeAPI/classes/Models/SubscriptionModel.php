<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 18/06/2017
* Time : 03:42 PM
**/

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;
class SubscriptionModel extends Emodel{
    protected $table = 'subscriptions';
    protected $primaryKey = 'id';
    public $timestamp = false;
    protected $fillable = [' ','created_at','updated_at'];
    protected $guarded = ['id'];

    public static function model($model = __CLASS__){
        return parent::model($model);
    }

    /**
    *@param data -array
    *@method - Create new subscription Packages.
    *@return - id of the new package or null if empty
    */

    public static function AddNewSubscriptionPackage($data = []){
        $subObj = new SubscriptionModel($data);
        if(!empty($subObj)){
            $subObj->save();
            return $subObj->id;
        }

        return null;
    }

    /**
    *@param id - Mixed 
    *@method - get the name of a subscription Package by Id.
    *@return - objects 
    */

    public static function getSubPackageById($id){
        $db_values = SubscriptionModel::find(['id'=>$id])->firstOrfail();
        if(!empty($db_values)){
            return $db_values;
        }
    }


    /**
    *@method - list all subscription Packages.
    *@return - array|mixed 
    */

    public static function getAllSubPackages(){
        return SubscriptionModel::all();
    }
}
