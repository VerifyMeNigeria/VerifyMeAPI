<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class LgaModel extends Emodel{

 protected $table = 'lga';
  
    public $timestamp = false;
    public $fillable = ['LGA_ID','LGA','STATE_ID'];
    public $guarded = [];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getLgaByStateid($data = array()){
        $db_value = LgaModel::where('STATE_ID','=', $data)
        ->orderBy('LGA')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }

    public static function getLgaById($data = array()){
        $db_value = LgaModel::where('LGA_ID','=', $data)
        ->orderBy('LGA')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
