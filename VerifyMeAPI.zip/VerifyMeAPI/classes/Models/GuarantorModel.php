<?php

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;

class GuarantorModel extends Emodel{
    protected $table = "guarantor";
    protected $fillable = ['grntInfoID','grntName','grntAddress','grntAddress','grntEmail','grntPhone','staffID','created_at','updated_at'];
    protected $guarded =['id'];

    public function __construct(){

    }

    public function model($className = __CLASS__){
        return $className;
    }

    public static function saveGuarantor($data = []){
        $obj = new GuarantorModel($data);
        $obj->grntInfoID = $data['grntInfoID'];
        $obj->grntName = $data['grntName'];
        $obj->grntAddress =  $data['grntAddress'];
        $obj->grntEmail = ($data['grntemail']) ? $data['grntemail'] : null;
        $obj->staffID = $data['staffID'];
        $obj->grntPhone = $data['grntPhone'];
        if(!empty($obj)){
            $obj->save();
        }
    }


}
