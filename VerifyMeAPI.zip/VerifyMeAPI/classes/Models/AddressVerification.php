<?php 
/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 14/08/2017
* Time : 10:36 PM
**/
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;
use Utils\Util;

class AddressVerification extends Emodel{
    protected $table = 'address_verification';
    public $primaryKey = 'id';
    public $timestamp = false;
    protected $fillable = ['staffid','agentid','address','latlong','housepic1','housepic2','streetpicture','contactname','contactphone','liveshere','verify', 'updated_at','created_at'];
    protected $guarded = ['id'];

    public function model($model = __CLASS__)
    {
        parent::model($model);
    }

    /**
     * function saves the address verification of an Employee.
     *
     * @param [type] $data
     * @return object
     */

     public function saveAddressverification($data){
         $addObj = new AddressVerification($data);
            $errorMessage = [];
             //$addObj->id = $data['id']; //required
             $addObj->staffid = $data['staffID']; //required
             $addObj->agentid = ($data['agent_id']) ? $data['agent_id'] : null;
             $addObj->address = $data['current_address']; //required
             //handling image upload
             $storage = './AddressVerificationpictures';
             $folder = '/';
             
             $image = Util::uploadFromData($data['housepic1'], $storage, $data['staffID'], $folder);
             
             $image2 = Util::uploadFromData($data['housepic2'], $storage, $data['staffID'], $folder);
             $street_picture = Util::uploadFromData($data['streetpicture'], $storage, $data['staffID'], $folder);
             $addObj->housepic1 = (!empty($image)) ? $image : " ";
             $addObj->housepic2 =  (!empty($image2)) ? $image2 : " ";
             $addObj->streetpicture = (!empty($street_picture)) ? $street_picture : " ";;
             $addObj->contactname = (!empty($data['contactname'])) ? $data['contactname'] : " " ;
             $addObj->contactphone = (!empty($data['contactphone'])) ? $data['contactphone'] : " " ;
             if(!empty($addObj->staffid)){
                 $addObj->save();
                return $addObj->staffid;
             }
             

     }

     public static function updateAddressVerification($data = [], $id){

            $addObj = self::findVerificationById($id);
         if(!empty($addObj)){
            $addObj->agentid = ($data['agent_id']) ? $data['agent_id'] : null;
             
             //handling image upload
             $storage = '../AddressVerificationpictures';
             $folder = '/';
             
             $image = Util::uploadFromData($data['housepic1'], $storage, $id . "_house1", $folder);
             
             $image2 = Util::uploadFromData($data['housepic2'], $storage, $id. "_house2", $folder);
             $street_picture = Util::uploadFromData($data['streetpicture'], $storage, $id. "_street", $folder);
             $addObj->housepic1 = (!empty($image)) ? $image : null;
             $addObj->housepic2 =  (!empty($image2)) ? $image2 : null;
             $addObj->streetpicture = (!empty($street_picture)) ? $street_picture : " ";;
             $addObj->contactname = (!empty($data['contactname'])) ? $data['contactname'] : " " ;
             $addObj->contactphone = (!empty($data['contactphone'])) ? $data['contactphone'] : " " ;
             $addObj->liveshere = $data['liveshere'];
             $addObj->verify = $data['verify'];
             $addObj->latlong = $data['latlong'];
             $addObj->save();
         }
     }

     public static function findVerificationById($data){
        $obj = AddressVerification::find($data);
        if(!empty($obj)){
        return $obj;
     }

}

}