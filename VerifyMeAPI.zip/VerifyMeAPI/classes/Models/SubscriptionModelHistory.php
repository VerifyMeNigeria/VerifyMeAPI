<?php

/**
* Created by VSC
* User: Valentine Troy Abako
* Date : 18/06/2017
* Time : 03:42 PM
**/

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;
class SubscriptionModelHistory extends Emodel{
    protected $table = 'subscription_history';
    protected $primaryKey = 'id';
    public $timestamp = false;
    protected $fillable = ['id','sub_id','empcode','payment_id','created_at','updated_at'];
    protected $guarded = [];

    public static function model($model = __CLASS__){
        return parent::model($model);
    }

    public static function makeSubscription($data = []){

    }

    public static function checkIfSubIsActive($data = []){

    }  
}