<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class EducationModel extends Emodel{

 protected $table = 'level_of_education';
  
    public $timestamp = false;
    public $fillable = ['education_level'];
    public $guarded = ['educationLvIID'];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getEducationLevel(){
        $db_value = EducationModel::orderBy('education_level')->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
    public static function listAllEducationById($data = array()){
        $db_value = EducationModel::where('educationLvlID','=', $data)
        ->orderBy('education_level')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
