<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class StateModel extends Emodel{

 protected $table = 'states';
    public $timestamp = false;
    public $fillable = ['STATE_ID','STATE'];
    public $guarded = [];

     public function model($model = __CLASS__)
    {
        parent::model($model);
    }

    /**
     * function to return Array of states in Ascending Order.
     *
     * @return Array
     */
    public static function getAllStates(){
        $data = StateModel::orderBy('STATE','ASC')->get();
        if($data){
            return $data;
        }
        return null;
    }

    public static function listAllStatesByStateId($data = array()){
        $db_value = StateModel::where('STATE_ID','=', $data)
        ->orderBy('STATE')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}