<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class EyeColourModel extends Emodel{

 protected $table = 'eye_colour';
  
    public $timestamp = false;
    public $fillable = ['colour'];
    public $guarded = ['eyeColourID'];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getEyeColour(){
        $db_value = EyeColourModel::orderBy('colour')->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }

    public static function getEyeColourById($data = array()){
        $db_value = EyeColourModel::where('eyeColourID','=', $data)
        ->orderBy('colour')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
