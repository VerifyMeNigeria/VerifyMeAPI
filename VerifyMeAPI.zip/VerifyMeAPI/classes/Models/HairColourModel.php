<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class HairColourModel extends Emodel{

 protected $table = 'hair_colours';
  
    public $timestamp = false;
    public $fillable = ['hair_colour'];
    public $guarded = ['hairColourID'];

     public function model($model = __CLASS__){
        parent::model($model);
    }

    public static function getHairColour(){
        $db_value = HairColourModel::orderBy('hair_colour')->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }

    public static function listAllHairColourById($data = array()){
        $db_value = HairColourModel::where('hairColourID','=', $data)
        ->orderBy('hair_colour')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}
