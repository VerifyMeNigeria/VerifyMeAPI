<?php 

namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;

class EmployersModel extends Emodel{

    protected $table = 'employers';
    public $primaryKey = 'empCode';
    public $timestamp = false;
    protected $fillable = ['empCode','empName','empAddress','empPhoneNumbers','empEmail','empType','ClientCode','dateregistered','mail_sent', 'auth_key','auth','disengage_mail'];
    protected $guarded = [];

    public function model($model = __CLASS__)
    {
        parent::model($model);
    }

    /**
     * function returns empcode of an Employee.
     *
     * @param [type] $data
     * @return object
     */
    public static function getEmployersByCode($data = []){
        $db_values = EmployersModel::where('empCode', $data)->get();
         $newData = $db_values->toArray();
        
        if($newData != null){
            if($newData[0]['empCode'] == 0) {
                $newData[0]['empCode'] = $data;
            }
            return $newData;
        }
        return null;
    }

    /**
    * @param data - array|Mixed
    * @return empcode.
    */

    public static function createEmployer($data){
        $db_values = new EmployersModel($data);
        $db_values->empCode = $data['empcode'];
        $db_values->empName = $data['empname'];
        $db_values->empAddress = $data['empaddress'];
        $db_values->empPhoneNumbers = $data['empPhone'];
        $db_values->empEmail = $data['empemail'];
        $db_values->empType = $data['empType'];
        if(!empty($db_values)){
            $db_values->save();
            return $db_values->empCode;
        }
    }

    public static function editInfo($empcode, $data = []){
        $db_values = EmployersModel::where('empCode',$empcode)->first();
        if(!empty($db_values)){
            $db_values->empAddress = $data['empaddress'];
            $db_values->empPhoneNumbers = $data['empPhone'];
            $db_values->empEmail = $data['empemail'];
            $db_values->save();
            return $empcode;
        }
        return null;
    } 
    
}