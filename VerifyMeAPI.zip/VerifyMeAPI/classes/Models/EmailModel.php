<?php
namespace Model;


class EmailModel{

    /**
     * A function to send Email
     *
     * @param array $data
     * @return void
     */

    public static function sendEmail($data = array()){

       $body = "<html><body>"; 
        $body .= "<div>
        <table border='0' cellpadding='0' cellspacing='0' width='600'>
            <tbody>
                <tr>
                    <td>
                        <p>
                            <div style='margin:0px 30px 0px 30px;padding-top:0px;color:#000000 ;font-size:medium;font-weight:normal'>
                                <p style='font-size:18px;font-weight:bold;color:#9a9661 '>Dear ".$data['empName'].",</p>
                                <p class='MsoNormal'> <span style='font-size:12.0pt;line-height:115%'>
                                    A new employee has been registered and assigned under you. Please click on the link below to approve or reject this employee's request.
<a href='/'>Link</a>
                                </div>
                        </p>
                        <p>
                             <img height='4' src='http://verifyme.ng/assets/img/line.png' width='600' class='CToWUd'>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img alt='ContactVMN' height='112' src='http://verifyme.ng/assets/img/contac.png' width='600' class='CToWUd'>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>"; 
    $body .= '</body></html>';
$FROM_NAME = "Verify Me Nigeria";

$FROM_EMAIL= "no-reply@verifymenigeria.com";
$Subject='Employee with the name' . $data['surname']. ' '. $data['firstname']. 'And VWN ID '.' '. $data['staffID'].' '. 'Awaits your Approval';
$mail = new \PHPMailer(true);
$mail->IsSMTP();

try{
   $mail->SMTPDebug = false;
   $mail->SMTPAuth = true;
   $mail->SMTPSecure = "none";
   $mail->Host ="mail.verifymenigeria.com";
   $mail->Port = 25;
   $mail->Username ="no-reply@verifymenigeria.com";
   $mail->Password ="P@55w0rd";
   $mail->SetFrom($FROM_EMAIL, $FROM_NAME);
   $mail->addAddress($data['empEmail']);
   //$mail->AddReplyTo($REPLY_EMAIL, $REPLY_NAME);
   //$mail->AddAddress($CUSTOMER_EMAIL, $CUSTOMER_NAME);
   //$mail->AddCC($CC_EMAIL,$CC_NAME);
   $mail->Subject = $Subject;

   $mail->MsgHTML($body);

   $mail->Send();
} catch (phpmailerException $e) {
      echo $e->errorMessage();
} catch (Exception $e) {
      echo $e->getMessage();
}  
    } 
	
	public static function sendEmailToEmployersUsingDevice($data = []){
    $body = "<html><body>"; 
        $body .= "<div>
        <table border='0' cellpadding='0' cellspacing='0' width='600'>
            <tbody>
                <tr>
                    <td>
                        <p>
                            <div style='margin:0px 30px 0px 30px;padding-top:0px;color:#000000 ;font-size:medium;font-weight:normal'>
                                <p style='font-size:18px;font-weight:bold;color:#9a9661 '>Dear ".$data['empName'].",</p>
                                <p class='MsoNormal'> <span style='font-size:12.0pt;line-height:115%'>
                                    A new employee has been added to your Profile.

                                </div>
                        </p>
                        <p>
                            <img height='4' src='http://verifyme.ng/assets/img/line.png' width='600' class='CToWUd'>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <img alt='ContactVMN' height='112' src='http://verifyme.ng/assets/img/contac.png' width='600' class='CToWUd'>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>"; 
    $body .= '</body></html>';
$FROM_NAME = "Verify Me Nigeria";
$FROM_EMAIL= "no-reply@verifymenigeria.com";
$Subject='Employee with the name' . $data['surname']. ' '. $data['firstname']. 'And VWN ID '.' '. $data['staffID'].' '. 'Has been added to your Account';
$mail = new \PHPMailer(true);
$mail->IsSMTP();

try{
   $mail->SMTPDebug = false;
   $mail->SMTPAuth = true;
   $mail->SMTPSecure = "none";
   $mail->Host ="mail.verifymenigeria.com";
   $mail->Port = 25;
   $mail->Username ="no-reply@verifymenigeria.com";
   $mail->Password ="P@55w0rd";
   $mail->SetFrom($FROM_EMAIL, $FROM_NAME);
   $mail->addAddress($data['empEmail']);
   //$mail->AddReplyTo($REPLY_EMAIL, $REPLY_NAME);
   //$mail->AddAddress($CUSTOMER_EMAIL, $CUSTOMER_NAME);
   //$mail->AddCC($CC_EMAIL,$CC_NAME);
   $mail->Subject = $Subject;

   $mail->MsgHTML($body);

   $mail->Send();
} catch (phpmailerException $e) {
      echo $e->errorMessage();
} catch (Exception $e) {
      echo $e->getMessage();
} 
}

}