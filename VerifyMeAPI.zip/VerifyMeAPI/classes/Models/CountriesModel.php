<?php
namespace  Model;
use \Illuminate\Database\Eloquent\Model as Emodel;


class CountriesModel extends Emodel{

 protected $table = 'countries';
    //protected $primaryKey = 'country_iso_code';
    public $timestamp = false;
    public $fillable = ['country_iso_code','country_name','priority'];
    public $guarded = [];
     public function model($model = __CLASS__)
    {
        parent::model($model);
    }

    /**
     *  function returns all the countries in the model.
     * @return array
     */
    public static function getAllcountries(){
        $data = CountriesModel::orderBy('country_name','ASC')->get();
        if($data){
            return $data;
        }
        return null;
        

    }

    public static function listAllCountryByCountryCode($data = array()){
        $db_value = CountriesModel::where('country_iso_code','=', $data)
        ->orderBy('country_name')
        ->get();
        if($db_value){
            return $db_value;
        }
        return null;
    }
}