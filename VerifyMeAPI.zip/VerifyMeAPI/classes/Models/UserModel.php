<?php

namespace Model;
use \Illuminate\Database\Eloquent\Model as Emodel;

class UserModel extends Emodel{
    protected $table = 'user_login';
    protected $primaryKey = 'username';
    public $timestamp = false;
    protected $fillable = ['username','password','role','fullname','token','token_exp_date', 'created_at','updated_at'];
    protected $guarded = [];

    public static function model($model = __CLASS__){
        return parent::model($model);
    }

    public static function login($data = []){
        $db_value = UserModel::where('username', $data['username'])->get();
        $newData = $db_value->toArray();
        if($newData!= null){
            if($newData[0]['username'] == 0) {
                $newData[0]['username'] = $data['username'];
            }
            
            return $newData;
        }
        return false;
    }

    /*
    *@param array $data
    *@method mixed $insertUser()
    *@return mixed
    *@todo create a new Users.
    */

    public static function insertUser($data = array()){
        $user = new UserModel($data);
        $user->username = $data['staffID'];
        $user->password = md5('VMNUSR');
        $user->role = 'employee';
        $full_name = $data['surname'].' '. $data['firstname']. $data['middlename'];
        $user->full_name = $full_name;
        $user->token = "N/A";
        $user->token_expires = "N/A";
        if(!empty($user)){
         $user->save();
         }
        }

        public static function insertUser($data = array()){
        $user = new UserModel($data);
        $user->username = $data['staffID'];
        $user->password = md5('VMNUSR');
        $user->role = 'employee';
        $full_name = $data['surname'].' '. $data['firstname']. $data['middlename'];
        $user->full_name = $full_name;
        $user->token = "N/A";
        $user->token_expires = "N/A";
        if(!empty($user)){
         $user->save();
         }
        }

        public static function IsEmployer(){

        }

        public static function isAdmin(){

        }

        public static function isEmployee(){

        }

        /**
        * @param $username - String
        * @return returns the role of a loggedIn User.
        * @methods  static
        **/
        public static function getUserDetails($username){
            $userObject = UserModel::where('username', $username)->firstOrfail();
            if(!empty($userObject)){
                return $userObject;
            }
        }
        
    
    
}