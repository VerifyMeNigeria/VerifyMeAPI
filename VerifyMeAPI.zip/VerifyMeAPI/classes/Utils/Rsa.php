<?php
namespace Utils;
use Utils\ResponseMessage;
use Utils\ResponseCode;

class Rsa{
    public $publicKey = '1234567890';
    public $privateKey = 'wordz345';
    public static function encrypt($data){
        if(openssl_public_encrypt($data, $encrypted, $publicKey))
            $data = base64_encode($encrypted);
        else
            throw new \Exception(['status'=> 'Error','Message'=> \ResponseMessage::ENCRYPT_DATA_ERROR, 'Code'=> \ResponseCode::ENCRYPT_DATA_ERROR]);
        return $data;
    }

    public static function decrypt($data){
         if(openssl_public_decrypt(base32_decode($data), $decrypted, $this->$privateKey))
         $data = $decrypted;
         else
         $data = '';
         return $data;
    }
}