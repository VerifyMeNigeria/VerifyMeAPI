<?php
namespace Util;
class ResponseCode {
const INVALID_USERNAME_OR_PASSWORD = "E001";
const ENCRYPT_DATA_ERROR = "E002";
const EMPCODE_ERROR = "E003";
const BVN_MESSAGE = "E004";
const PHONE_MESSAGE = "E005";
const EMPLOYER_ERROR = "E006";
const EMPCODE_STAFFID_STATUS = "E007";
}