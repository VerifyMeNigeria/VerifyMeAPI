<?php
namespace Utils;
use Model\UserModel;
class Util{
    private static $instance = null;

    public static function getInstance(){
        if(self::$instance == null){
            return self::$instance = new Util();//if instance is null make it the instance of the class
        }
        return self::$instance;
    }

    /**
    *@params key : string
    *@params value : string
    *@method returns boolean.
    * method create a session.
    */
    public function makeSession($key, $value = null){
        //the serialized function converts the actual session data into a format that is storable in the computer.

        if(!isset($_SESSION[$key])){
            if($key!= null && $value!= null){
                $_SESSION[$key] = serialize($value); // if the value of the session is provided then save the session.

            }elseif($key == null && $value == null && isset($_SESSION[$key])){
                    return unserialize($_SESSION[$key]); // if no value is provided and session is set then get back the session.

            }elseif(isset($_SESSION[$key])){
                return unserialize($_SESSION[$key]);

            }else{
                return false;
            }
        }
    }

    /**
    *@param key: string
    *@param value : string
    *@method returns session_value
    * method starts a session and assigns a value to the session
    */
    public function startSession($key, $value){
        //session_start();
        return $_SESSION[$key] = $value;
    }

    public function isLoggedIn(){
        return $this->makeSession('loggedin');
    }

    public  function destorySession($key, $value){
        unset($_SESSION[$key]);
        $_SESSION[$key] = null;
        session_destroy();
    }

    public function session($key){
         $this->isLoggedIn();
        $value = $_SESSION[$key];
        return unserialize($value);
    }


    /**
 * function to store customers image
 *
 * @param [type] $data
 * @param [type] $storage
 * @param string $folder
 * @return void
 */
public static function uploadFromData($data, $storage, $employee_id, $folder = '/') {
    $ext = "jpg";
    
        $image = base64_decode($data);
       
        $filename = $employee_id .'.'. $ext;
        //storage = '/Applications/MAMP/htdocs/VerifyMeAPI/picture/'
        if(file_put_contents($storage . $folder . $filename, $image) !== FALSE) {
            return $storage.$folder.$filename;
        }
 //   }
    
    return null;
}



}