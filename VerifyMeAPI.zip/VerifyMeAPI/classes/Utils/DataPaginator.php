<?php  

namespace Util;
use  BaseController;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;
use Model\StaffEmployementHistoryModel;
public class DataPaginator{
    
public function pagination(Request $request, Response $response, $args){
    $page  =   ($req->getParam('page', 0) > 0) ? $req->getParam('page') : 1;
    $limit     = 25; // Number of posts on one page
    $skip      = ($page - 1) * $limit;
    $count     = StaffEmployementHistoryModel::getCount([]); // Count of all availables work history

    return $res->withJson([
        'pagination'    => [
            'needed'        => $count > $limit,
            'count'         => $count,
            'page'          => $page,
            'lastpage'      => (ceil($count / $limit) == 0 ? 1 : ceil($count / $limit)),
            'limit'         => $limit,
        ],
        // return list of Posts with Limit and Skip arguments
        'employeeHistory'         => Post::getList([
            'limit'         => $limit,
            'skip'          => $skip,
        ])
    ]);

}


}