<?php
namespace Util;
class ResponseMessage {
const INVALID_USERNAME_OR_PASSWORD = "Invalid Username or Password";
const ENCRYPT_DATA_ERROR = "Unable to encrypt data. perhaps it is bigger than the key size?";
const EMPCODE_ERROR = "Invalid employer Code";
const BVN_MESSAGE = "Bvn is Required";
const PHONE_MESSAGE = "Phone number Required";
const EMPLOYER_ERROR = "employer already exist";
const EMPCODE_STAFFID_STATUS = "Empcode, Staffid does not exist";

}