<?php
return [
    'settings' => [
        'displayErrorDetails' => true, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header

        // Renderer settings
        'renderer' => [
            'template_path' => __DIR__ . '/../templates/',
        ],

        // Monolog settings
        'logger' => [
            'name' => 'slim-app',
            'path' => __DIR__ . '/../logs/app.log',
            'level' => \Monolog\Logger::DEBUG,
        ],

            //staging Connection

        /**'db'=> [
            'driver' =>'mysql',
            'host'=> '162.144.199.162:3306',
            'database'=> 'vmdb',
            'username'=> 'VerifyMe_User',
            'password'=> '77VerifyMe77!',
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix' => '',

         ]
         **/
         

         //local connection
        
         'db'=> [
            'driver' =>'mysql',
            'host'=> 'localhost',
            'database'=> 'vmdb',
            'username'=> 'root',
            'password'=> 'root',
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix' => '',

         ]
         

         //Production Connection

         /**'db'=> [
            'driver' =>'mysql',
            'host'=> '162.144.199.162:3306',
            'database'=> 'VerifyMe_Prod_DB',
            'username'=> 'VerifyMe_PD',
            'password'=> '77VerifyMe77!',
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix' => '',

         ]
         **/


         

    ],
];
