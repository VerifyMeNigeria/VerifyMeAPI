<?php
// Routes

use Middleware\AuthMiddleware;
//use Middleware\GuestMiddleware;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface  as Response;

//Localserver Credential MAMP : username:root, password:vmnroot

$app->post('/login', '\Controllers\UserController:login')->setName('user');
$app->get('/verifyemp/{empcode}', '\Controllers\EmployersController:getEmployersByEmpcode');
$app->get('/countries', '\Controllers\CountriesController:getAllCountries' );
$app->get('/states', '\Controllers\StateController:getAllState' );
$app->get('/lga/{state_id}', '\Controllers\LgaController:getAllLgaByStateid');
$app->get('/occupation', '\Controllers\OccupationController:getAllOccupation');
$app->get('/eyecolour', '\Controllers\EyeColourController:getEyeColour');
$app->get('/haircolour', '\Controllers\HairColourController:getHairColour');
$app->get('/educationLevel', '\Controllers\EducationController:getEducationLevel');
$app->get('/nextofkintypes', '\Controllers\NextofKinTypeController:getNextofKinLevel');
$app->post('/validatebvnAndPhone','\Controllers\EmployeesController:CheckIfBvnOrPhoneExist');
$app->post('/employee/saveEmployeeid','\Controllers\EmployeesController:saveEmployeeid');
$app->post('/employee/selfreg','\Controllers\EmployeesController:selfRegistration');
$app->post('/employer/register','\Controllers\EmployersController:saveEmployer');
$app->get("/logout", function (Request $request, Response $response, $args){unset($_SESSION['user']); unset($_SESSION['role']);session_destroy();
   return $response->withJson(['status'=>true , 'Message'=> 'SuccessFully Logged Out']);
   //$app->render('logout.php');
});



//Protected API
$app->group('', function() use ($app){
    $app->get('/employee/staffid/{staffid}', '\Controllers\EmployeesController:findEmployeeByStaffId');
})->add(new AuthMiddleware());


$app->post('/employee/address_verification','\Controllers\AddressVerificationController:saveAddressverification');
$app->put('/employee/update/address_verification/{id}','\Controllers\AddressVerificationController:updateAddressVerification');
$app->get('/employer/staffs/{empcode}','\Controllers\StaffEmployementHistoryController:getEmployersStaffsAndDetails');
$app->post('/employer/staff/history','\Controllers\StaffEmployementHistoryController:getEmployeeHistorythatBelongToEmployer');
$app->put('/employer/update/{empcode}','\Controllers\EmployersController:editInfo');
$app->put('/employer/disengage/employee/{empcode}','\Controllers\StaffEmployementHistoryController:disengageEmployeeByEmployer');

//


$app->get('/[{name}]', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});

$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

$app->add(function ($req, $res, $next) {
    $response = $next($req, $res);
    return $response
            ->withHeader('Access-Control-Allow-Origin', 'http://http://localhost/EmployerPortal/public/index.html')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
});